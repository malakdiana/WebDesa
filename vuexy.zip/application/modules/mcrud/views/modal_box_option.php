<div class="box-option">
  <div class="box-option-item">
    <div class="box">
      <label for="">label</label>
      <input type="text" name="mcrud[<?=$sort?>][<?=$field_name?>][option][0][label]">
    </div>
    <div class="box">
      <label for="">value</label>
      <input type="text" name="mcrud[<?=$sort?>][<?=$field_name?>][option][0][value]">
    </div>
  </div>
</div>
<a class="btn btn-sm btn-block add-option"><i class="fa fa-plus"></i> Add New</a>
