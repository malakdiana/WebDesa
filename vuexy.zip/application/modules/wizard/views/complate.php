<h3>Instalation Complate</h3>
<section>
  <div class="row">
    <div class="col-lg-12 steps6 card-description">
      <h4>Instalation Complate</h4>
      <hr>
      <div id="content-complate"></div>

    </div>
  </div>
</section>
