<h3>Site & User Configuration</h3>
<section>
  <div class="row">
    <div class="col-lg-12 steps5 card-description">
      <h4>Site & User Configuration</h4>
      <hr>
      <div class="form-group">
        <label for="">App/Web Name</label>
        <input type="text" class="form-control" id="app_name" id="app_name" placeholder="App/Web Name">
      </div>

      <div class="form-group">
        <label for="">Developer Name</label>
        <input type="text" class="form-control" id="dev_name" name="dev_name" placeholder="Developer Name">
      </div>

      <div class="form-group">
        <label for="">Email</label>
        <input type="text" class="form-control" id="email" name="email" placeholder="Email">
      </div>

      <div class="form-group">
        <label for="">Password</label>
        <input type="text" class="form-control" id="password" name="password" placeholder="Password">
      </div>


    </div>
  </div>
</section>
