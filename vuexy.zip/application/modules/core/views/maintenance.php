
<div class="row">
  <div class="col-lg-12 text-center">
    <div class="card">
      <div class="card-body">
        <img src="<?=base_url()?>_temp/backend/maintenance.gif" alt="maintenance" width="500" height="300">
        <h3 class="card-title">Sorry, System Maintenance</h3>
      </div>
    </div>
  </div>
</div>
