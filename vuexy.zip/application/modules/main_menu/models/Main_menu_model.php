<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/* dev : Muhammad Royyan Zamzami*/


/* Generate By M-CRUD Generator 10/11/2020 14:51*/
/* Please DO NOT modify this information */
class Main_menu_model extends MY_Model{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
  }

}
