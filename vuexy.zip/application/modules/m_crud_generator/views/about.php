<style media="screen">
  ul.features, .sosmed{
    list-style: none;
  }
</style>
<div class="col-sm-12 steps1 card-description">
  <h4>m-code panel + m-crud generator codeigniter 3</h4>
  <hr>
  <h5>Features </h5>
  <ul class="features mb-3">
    <li><i class="ti-check"></i> Crud Generator by M-CRUD</li>
    <li><i class="ti-check"></i> Role-based access control (RBAC) user</li>
    <li><i class="ti-check"></i> Module user</li>
    <li><i class="ti-check"></i> Module group</li>
    <li><i class="ti-check"></i> Module permission</li>
    <li><i class="ti-check"></i> Module filemanager</li>
    <li><i class="ti-check"></i> Module menu management</li>
    <li><i class="ti-check"></i> setting system</li>
    <li><i class="ti-check"></i> setting maintenace</li>
    <li><i class="ti-check"></i> setting user log activity</li>
    <li><i class="ti-check"></i> update logo , logo mini, favicon</li>
    <li><i class="ti-check"></i> update route login and panel</li>
    <li><i class="ti-check"></i> encryption url</li>
    <li><i class="ti-check"></i> update timezone</li>
    <li><i class="ti-check"></i> update encryption key</li>
    <li><i class="ti-check"></i> update language english and indonesia</li>
    <li><i class="ti-check"></i> support ajax crud</li>
    <li><i class="ti-check"></i> support Datatable serverside</li>
    <li><i class="ti-check"></i> support text editor summernote inculde module file manager</li>
    <li><i class="ti-check"></i> Bulilt in PHP Version 7.4</li>
    <li><i class="ti-check"></i> tester web hosting php version 5.6 - 7.4</li>
    <li><i class="ti-check"></i> CI Version 3.1.11</li>
</ul>

<hr>

<h5>Follow & Subscibe</h5>
<ul class="sosmed mb-3">
  <li><a href="<?=$this->config->item("youtube")?>" target="_blank"><i class="ti-youtube cl-youtube"></i> Youtube Channel</a></li>
  <li><a href="<?=$this->config->item("fanspage")?>" target="_blank"><i class="ti-facebook cl-facebook"></i> Fanspage Facebook</a></li>
  <li><a href="<?=$this->config->item("instagram")?>" target="_blank"><i class="ti-instagram cl-instagram"></i> Instagram</a></li>
</ul>

<hr>

<h5>Developer</h5>
<ul class="sosmed mb-3">
  <li><a href="<?=$this->config->item("facebook")?>" target="_blank" target="_blank"><?=ucfirst($this->config->item("author"))?></a></li>
  <li><a href="https://web.facebook.com/awan.nightmare" target="_blank" target="_blank">Mallombassi Dg Mattawang</a></li>
</ul>

<hr>

<p>Untuk membantu kami mengembangkan tools ini bisa dengan cara donasi buat ngopi  :)</p>
<ul class="sosmed mb-3">
  <li>BNI 0330538612 / Muh.irfan ibnu</li>
</ul>

<a href="">#salam_keyboard!!!! :)</a>
</div>
