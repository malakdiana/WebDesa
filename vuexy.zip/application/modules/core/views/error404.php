<div class="row">
  <div class="col-md-12 col-xl-6 mx-auto animated fadeIn delay-2s text-center">
    <img class="mb-3" src="<?=base_url()?>_temp/backend/not-found.gif" height="250" width="400">
    <h5> Error 404, Page Not Found</h5>
  </div>
</div>
