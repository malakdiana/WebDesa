<div class="row">
  <div class="col-md-12 col-xl-6 mx-auto animated fadeIn delay-2s text-center">
    <h3>Sorry!</h3>
    <img class="mb-3" src="<?=base_url()?>_temp/backend/desktop-access-disabled.png" height="150" width="150">
    <h5> You do not have permission to access</h5>
  </div>
</div>
