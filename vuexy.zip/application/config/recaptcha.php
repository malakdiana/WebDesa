<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// recaptcha_sitekey google
$config['recaptcha_sitekey'] =  "6Lfrr6QZAAAAAFRG2cK5imApCXY1gRIa9FnTOgZf";

$config['recaptcha_secretkey'] = "6Lfrr6QZAAAAAHKvTRhoQm8CcnxmRE2E8TFPcBTZ";

$config['lang'] = "id";
